<?php
/*
$link = mysqli_connect("Localhost","root","","autotechcare");
if (mysqli_connect_error())
{
echo "MYSQLi Connection was not established: " . mysqli_connect_error();
}
*/
?>

<?php
$link = mysqli_connect("Localhost","vrutik_autotechcare","Vrutik6201","vrutik_autotechcare");
if (mysqli_connect_error())
{
echo "MYSQLi Connection was not established: " . mysqli_connect_error();
}
?>